#include "Engine.hh"

int		main()
{
  Engine	engine;

  engine.start();
  return (0);
}
